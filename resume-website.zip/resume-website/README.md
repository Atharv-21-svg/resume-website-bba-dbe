# Resume Website

Personal resume website built with plain HTML and CSS.

## Files
- `index.html` : page structure and content
- `style.css` : all styling

## Host on GitHub Pages
1. Open your existing resume repository on GitHub.
2. Click **Add file > Upload files**, drag in `index.html` and `style.css` (overwrite the old `index.html`), and commit.
3. Go to **Settings > Pages**. Under **Branch**, choose `main` and `/ (root)`, then Save.
4. After a minute your live link appears: `https://<your-username>.github.io/<repo-name>/`

Keep `index.html` and `style.css` in the same folder, because the HTML links to the CSS by file name.
